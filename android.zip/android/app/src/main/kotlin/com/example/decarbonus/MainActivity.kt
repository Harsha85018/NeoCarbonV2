package com.example.decarbonus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
